import React, { useReducer } from "react";

let App = () => {

let reducerFun = (state, action) => {
  switch (action.type) {
    case "UPDATE_USER_DETAILS":
      return { ...state,user: {...state.user,[action.field]: action.value}};
    default:
      return state;
  }
};

  let [state, dispatch] = useReducer(reducerFun, {user: {name: "",email: "",age: 0,phone: ""}});

  let userDetailsChangeHandler = (field, value) => { dispatch({type: "UPDATE_USER_DETAILS",field,value }) };

  return (
    <div className="container">
      <h1>Form using Reducer Hook</h1>
      <div className="mb-3">
        <label htmlFor="name" className="form-label">User Name</label>
        <input onChange={(e) => userDetailsChangeHandler("name", e.target.value)} value={state.user.name} className="form-control" id="name" placeholder="User Name"/>
      </div>
      <div className="mb-3">
        <label htmlFor="email" className="form-label">User Email</label>
        <input onChange={(e) => userDetailsChangeHandler("email", e.target.value)} value={state.user.email} className="form-control" id="name" placeholder="User Email"/>
      </div>
      <div className="mb-3">
        <label htmlFor="age" className="form-label">User Age </label>
        <input type="Number" onChange={(e) => userDetailsChangeHandler("age", e.target.value)} value={state.user.age} className="form-control" id="name" placeholder="User age"/>
      </div>
      <div className="mb-3">
        <label htmlFor="phone" className="form-label">User Phone</label>
        <input onChange={(e) => userDetailsChangeHandler("phone", e.target.value)} value={state.user.phone} className="form-control" id="name" placeholder="User phone"/>
      </div>
      <div className="mb-3">
        <button className="btn btn-primary">Register</button>
      </div>
      <ul>
        <li>User Name: {state.user.name}</li>
        <li>User eMail: {state.user.email}</li>
        <li>User Age: {state.user.age}</li>
        <li>User Phone: {state.user.phone}</li>
      </ul>
    </div>
  );
};

export default App;
