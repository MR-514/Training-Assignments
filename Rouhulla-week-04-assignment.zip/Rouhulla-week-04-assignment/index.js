const express = require("express");
const fs = require("node:fs");

const config = require("./config.json");
const app = express();
app.use(express.urlencoded({ extended: true }));

const data = require("./data/hero-list.json");

let avengers =[];
// console.log(avengers)

app.get("/", (req, res) => {
   // console.log(avengers)
    // res.render("home.pug", { avengers });
    res.render("home.ejs", { avengers });
});

app.post("/", (req, res) => {

    const newAvenger = {
        title: req.body.heroTitle,
        firstname: req.body.heroFname,
        lastname: req.body.heroLname,
        power: req.body.heroPower,
        city: req.body.heroCity
    };

    avengers.push(newAvenger);
    data.avengers.push(newAvenger);



  fs.writeFileSync("./data/hero-list.json", JSON.stringify(data), "utf-8");

  // console.log(avengers);
  res.redirect("/");
});

app.listen(config.port, config.host, (error) => {
  error
    ? console.log("Error", error)
    : console.log(`server is now live on ${config.host}:${config.port}`);
});
// console newly added avenger
console.log(avengers);
