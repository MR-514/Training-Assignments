import { Component } from "react";
import Header from "./header.component";
import Footer from "./footer.component";
import Plan from "./plan.component";
import Compare from "./compare-plans";
import Tick from "./tick";

class App extends Component{
    render(){
        return <div class="container py-3">
            <Tick/>
        <Header/>
        <main>
        <div className="row row-cols-1 row-cols-md-3 mb-3 text-center">
            <Plan/>
            <Plan/>
            <Plan/>
    </div>
    <h2 className="display-6 text-center mb-4">Compare plans</h2>
    <Compare/>
    </main>
    
        <Footer/>
    </div>
    }
}
export default App