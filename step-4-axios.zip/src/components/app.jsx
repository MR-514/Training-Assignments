import { Component } from "react"
import axios from "axios";

class App extends Component{
    state = {
        users : []
    }

    // odd heros with different color and even heros with difft color using css and javascript
    componentDidMount(){
        axios.get("https://reqres.in/api/users?page=2")
        .then( res => this.setState({users : res.data.data}))
        .catch(err => console.log("Error",err))
    }
    render(){
        console.log("App Component's render was called")
       return <div>
                   <h1>Ajax | API Call</h1>
                   <hr/>
                   <ol>
                    { this.state.users.map( val => <li key = {val.id} style={{ backgroundColor :val.id%2 === 0 ? "red" : "aqua"}}><img src={val.avatar}/> {val.first_name} {val.last_name}</li>)}

                   </ol>

               </div>
    }
}
 
export default App;
