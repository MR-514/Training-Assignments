import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  ScrollView,
  Text,
  View,
} from "react-native";
import Header from "./components/header";
function App() {
  const herolist = [
    {
      title: "Srinagar",
      poster: require("./assets/images/heroes/ironman.jpg"),
    },
    {
      title: "Jammu",
      poster: require("./assets/images/heroes/batman.jpg"),
    },
    {
      title: "Banglore",
      poster: require("./assets/images/heroes/superman.jpg"),
    },
    { title: "Kolkata", poster: require("./assets/images/heroes/antman.jpg") },
    {
      title: "New Delhi",
      poster: require("./assets/images/heroes/spiderman.jpg"),
    },
    {
      title: "Kochi",
      poster: require("./assets/images/heroes/rajani.jpg"),
    },
    {
      title: "Delhi",
      poster: require("./assets/images/heroes/hulk.jpg"),
    },
    {
      title: "JPNagar",
      poster: require("./assets/images/heroes/blackpanther.jpg"),
    },
    {
      title: "Delhi",
      poster: require("./assets/images/heroes/hulk.jpg"),
    },
    {
      title: "JPNagar",
      poster: require("./assets/images/heroes/blackpanther.jpg"),
    },
  ];

  return (
    <SafeAreaView style={{ margin: 15 }}>
      <Header />
      <ScrollView>
        <View
          style={{
            flexDirection: "row",
            flexWrap: "wrap",
            justifyContent: "space-between",
          }}
        >
          {herolist.map((val, idx) => (
            <View key={idx}>
              <ImageBackground
                style={{ height: 180, width: 180 }}
                source={val.poster}
              >
                
                  <Text
                    style={{
                      textAlign:"center",
                      top: "83%",
                      left: 0,
                      color:"white",
                      backgroundColor: "rgba(0,0,0,0.7)",
                      height: 30,
                    }}
                  >
                    {val.title}
                  </Text>
                
              </ImageBackground>
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

export default App;
