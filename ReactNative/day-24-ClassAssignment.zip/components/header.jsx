import { Image, Text, View, ViewBase } from "react-native"

export default Header = () => {
  return (
    <View
      style={{
        padding: 15,
        height: 100,
        backgroundColor: "crimson",
        display: "flex",
        flexDirection:'row',
        justifyContent: "space-between",
      }}
    >

        <Image
          style={{ width: 60, height: 60 }}
          source={{
            uri: "https://images.unsplash.com/photo-1567446537708-ac4aa75c9c28?q=80&w=1887&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
          }}
        />
 

        <Image
          style={{ width: 60, height: 60 }}
          source={{
            uri: "https://images.unsplash.com/photo-1511367461989-f85a21fda167?q=80&w=1931&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
          }}
        />

    </View>
  );
}