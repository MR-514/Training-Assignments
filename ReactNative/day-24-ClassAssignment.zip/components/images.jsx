import { Image, ImageBackground, Text, View } from "react-native"

export default Cities = () => {
  return (
    <View>
      <View
        style={{
          display: "flex",
          flexDirection: "row",
          gap: "2%",
        }}
      >
        <ImageBackground>
          <Image
            style={{ width: "45%", height: 200 }}
            source={{
              uri: "https://images.unsplash.com/photo-1531846802986-4942a5c3dd08?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Y2l0aWVzfGVufDB8fDB8fHww",
            }}
          />
          <Text style={{ color: "white" }}>New York</Text>
        </ImageBackground>
        <ImageBackground>
          <Image
            style={{ width: "45%", height: 200 }}
            source={{
              uri: "https://plus.unsplash.com/premium_photo-1680582107403-04dfac02efc3?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8Y2l0aWVzfGVufDB8fDB8fHww",
            }}
          />
          <Text style={{ color: "white" }}>DownTown</Text>
        </ImageBackground>
      </View>
      <View
        style={{
          display: "flex",
          flexDirection: "row",
          gap: "2%",
        }}
      >
        <ImageBackground>
          <Image
            style={{ width: "45%", height: 200 }}
            source={{
              uri: "https://images.unsplash.com/photo-1531846802986-4942a5c3dd08?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Y2l0aWVzfGVufDB8fDB8fHww",
            }}
          />
          <Text style={{ color: "white" }}>Brooklyn</Text>
        </ImageBackground>
        <ImageBackground>
          <Image
            style={{ width: "45%", height: 200 }}
            source={{
              uri: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?q=80&w=1888&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
            }}
          />
          <Text style={{}}>Chicago</Text>
        </ImageBackground>
      </View>
      <View
        style={{
          display: "flex",
          flexDirection: "row",
          gap: "2%",
        }}
      >
        <ImageBackground>
          <Image
            style={{ width: "45%", height: 200 }}
            source={{
              uri: "https://images.unsplash.com/photo-1588733103629-b77afe0425ce?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fGNpdGllc3xlbnwwfHwwfHx8MA%3D%3D",
            }}
          />
          <Text style={{ color: "white" }}>Toronto</Text>
        </ImageBackground>
        <ImageBackground>
          <Image
            style={{ width: "45%", height: 200 }}
            source={{
              uri: "https://images.unsplash.com/photo-1555397430-57791c75748a?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
            }}
          />
          <Text style={{ color: "white" }}>Japan</Text>
        </ImageBackground>
      </View>
    </View>
  );
}